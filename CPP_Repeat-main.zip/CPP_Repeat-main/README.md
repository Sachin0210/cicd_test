## This is an Open source system forAdityatic and Courier website.

# This is a simple system for managing courier andAdityatic services.

# This system is designed to manage courier andAdityatic services, including tracking packages, managing drivers, and

# managing customers.

install and use as you desire but give credit to LearnPro Nigeria and Versity ICT Solutions
the frontend design is by Madebybootstrap and should be acknoledged too.

# Please make sure to subscribe to my YouTube channel
